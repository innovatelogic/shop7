openpyxl.chart.layout module
============================

.. automodule:: openpyxl.chart.layout
    :members:
    :undoc-members:
    :show-inheritance:
