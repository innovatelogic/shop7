openpyxl.chart.axis module
==========================

.. automodule:: openpyxl.chart.axis
    :members:
    :undoc-members:
    :show-inheritance:
