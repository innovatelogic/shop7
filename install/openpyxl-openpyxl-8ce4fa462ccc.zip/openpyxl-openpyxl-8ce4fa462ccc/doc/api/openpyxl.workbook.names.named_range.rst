openpyxl.workbook.names.named_range module
==========================================

.. automodule:: openpyxl.workbook.names.named_range
    :members:
    :undoc-members:
    :show-inheritance:
