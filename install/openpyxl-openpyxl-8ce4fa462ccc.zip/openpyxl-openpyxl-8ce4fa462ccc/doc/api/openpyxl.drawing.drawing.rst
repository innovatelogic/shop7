openpyxl.drawing.drawing module
===============================

.. automodule:: openpyxl.drawing.drawing
    :members:
    :undoc-members:
    :show-inheritance:
