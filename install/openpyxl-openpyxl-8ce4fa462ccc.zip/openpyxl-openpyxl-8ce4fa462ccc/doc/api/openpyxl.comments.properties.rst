openpyxl.comments.properties module
===================================

.. automodule:: openpyxl.comments.properties
    :members:
    :undoc-members:
    :show-inheritance:
