openpyxl.comments.author module
===============================

.. automodule:: openpyxl.comments.author
    :members:
    :undoc-members:
    :show-inheritance:
