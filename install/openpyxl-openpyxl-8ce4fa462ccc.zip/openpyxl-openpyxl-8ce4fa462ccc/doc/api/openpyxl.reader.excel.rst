openpyxl.reader.excel module
============================

.. automodule:: openpyxl.reader.excel
    :members:
    :undoc-members:
    :show-inheritance:
