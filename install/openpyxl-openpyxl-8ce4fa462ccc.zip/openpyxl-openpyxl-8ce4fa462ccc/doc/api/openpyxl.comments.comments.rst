openpyxl.comments.comments module
=================================

.. automodule:: openpyxl.comments.comments
    :members:
    :undoc-members:
    :show-inheritance:
