openpyxl.utils.exceptions module
================================

.. automodule:: openpyxl.utils.exceptions
    :members:
    :undoc-members:
    :show-inheritance:
