openpyxl.descriptors.excel module
=================================

.. automodule:: openpyxl.descriptors.excel
    :members:
    :undoc-members:
    :show-inheritance:
