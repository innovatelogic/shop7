openpyxl.drawing.spreadsheet_drawing module
===========================================

.. automodule:: openpyxl.drawing.spreadsheet_drawing
    :members:
    :undoc-members:
    :show-inheritance:
