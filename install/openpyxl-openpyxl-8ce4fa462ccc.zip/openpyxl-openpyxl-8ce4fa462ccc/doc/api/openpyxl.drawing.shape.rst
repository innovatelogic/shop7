openpyxl.drawing.shape module
=============================

.. automodule:: openpyxl.drawing.shape
    :members:
    :undoc-members:
    :show-inheritance:
