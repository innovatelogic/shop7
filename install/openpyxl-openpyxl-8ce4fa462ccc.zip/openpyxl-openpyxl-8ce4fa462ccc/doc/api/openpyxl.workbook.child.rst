openpyxl.workbook.child module
==============================

.. automodule:: openpyxl.workbook.child
    :members:
    :undoc-members:
    :show-inheritance:
