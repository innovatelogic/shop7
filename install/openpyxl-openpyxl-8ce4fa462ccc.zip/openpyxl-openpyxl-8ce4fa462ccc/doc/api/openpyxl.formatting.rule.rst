openpyxl.formatting.rule module
===============================

.. automodule:: openpyxl.formatting.rule
    :members:
    :undoc-members:
    :show-inheritance:
