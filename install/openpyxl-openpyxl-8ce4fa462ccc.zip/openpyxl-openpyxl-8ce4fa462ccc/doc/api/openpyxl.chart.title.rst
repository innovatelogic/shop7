openpyxl.chart.title module
===========================

.. automodule:: openpyxl.chart.title
    :members:
    :undoc-members:
    :show-inheritance:
