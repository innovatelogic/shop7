openpyxl.writer.relations module
================================

.. automodule:: openpyxl.writer.relations
    :members:
    :undoc-members:
    :show-inheritance:
