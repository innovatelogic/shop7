openpyxl.xml.constants module
=============================

.. automodule:: openpyxl.xml.constants
    :members:
    :undoc-members:
    :show-inheritance:
