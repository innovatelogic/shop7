openpyxl.chart.picture module
=============================

.. automodule:: openpyxl.chart.picture
    :members:
    :undoc-members:
    :show-inheritance:
