openpyxl.styles.colors module
=============================

.. automodule:: openpyxl.styles.colors
    :members:
    :undoc-members:
    :show-inheritance:
