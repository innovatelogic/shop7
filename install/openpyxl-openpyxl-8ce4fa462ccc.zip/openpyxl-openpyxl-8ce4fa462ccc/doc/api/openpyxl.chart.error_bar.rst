openpyxl.chart.error_bar module
===============================

.. automodule:: openpyxl.chart.error_bar
    :members:
    :undoc-members:
    :show-inheritance:
