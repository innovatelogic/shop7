openpyxl.descriptors.nested module
==================================

.. automodule:: openpyxl.descriptors.nested
    :members:
    :undoc-members:
    :show-inheritance:
