openpyxl.drawing.shapes module
==============================

.. automodule:: openpyxl.drawing.shapes
    :members:
    :undoc-members:
    :show-inheritance:
