openpyxl.styles.numbers module
==============================

.. automodule:: openpyxl.styles.numbers
    :members:
    :undoc-members:
    :show-inheritance:
