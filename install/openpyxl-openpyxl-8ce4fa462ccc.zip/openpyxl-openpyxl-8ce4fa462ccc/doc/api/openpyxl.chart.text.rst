openpyxl.chart.text module
==========================

.. automodule:: openpyxl.chart.text
    :members:
    :undoc-members:
    :show-inheritance:
