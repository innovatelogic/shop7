openpyxl.chart.marker module
============================

.. automodule:: openpyxl.chart.marker
    :members:
    :undoc-members:
    :show-inheritance:
