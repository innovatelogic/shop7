openpyxl.descriptors.serialisable module
========================================

.. automodule:: openpyxl.descriptors.serialisable
    :members:
    :undoc-members:
    :show-inheritance:
