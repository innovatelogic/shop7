openpyxl.chart.legend module
============================

.. automodule:: openpyxl.chart.legend
    :members:
    :undoc-members:
    :show-inheritance:
