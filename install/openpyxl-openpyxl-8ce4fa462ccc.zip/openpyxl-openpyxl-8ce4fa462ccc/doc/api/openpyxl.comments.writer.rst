openpyxl.comments.writer module
===============================

.. automodule:: openpyxl.comments.writer
    :members:
    :undoc-members:
    :show-inheritance:
