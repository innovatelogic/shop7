openpyxl.descriptors.namespace module
=====================================

.. automodule:: openpyxl.descriptors.namespace
    :members:
    :undoc-members:
    :show-inheritance:
