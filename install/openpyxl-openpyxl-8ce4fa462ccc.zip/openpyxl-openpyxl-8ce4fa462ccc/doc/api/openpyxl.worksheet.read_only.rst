openpyxl.worksheet.read_only module
===================================

.. automodule:: openpyxl.worksheet.read_only
    :members:
    :undoc-members:
    :show-inheritance:
