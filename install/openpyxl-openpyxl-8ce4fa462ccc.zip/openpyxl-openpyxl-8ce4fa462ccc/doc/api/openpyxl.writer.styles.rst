openpyxl.writer.styles module
=============================

.. automodule:: openpyxl.writer.styles
    :members:
    :undoc-members:
    :show-inheritance:
