openpyxl.chart.data_source module
=================================

.. automodule:: openpyxl.chart.data_source
    :members:
    :undoc-members:
    :show-inheritance:
