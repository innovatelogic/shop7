openpyxl.styles.hashable module
===============================

.. automodule:: openpyxl.styles.hashable
    :members:
    :undoc-members:
    :show-inheritance:
