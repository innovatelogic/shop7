openpyxl.chart.stock_chart module
=================================

.. automodule:: openpyxl.chart.stock_chart
    :members:
    :undoc-members:
    :show-inheritance:
