openpyxl.comments.reader module
===============================

.. automodule:: openpyxl.comments.reader
    :members:
    :undoc-members:
    :show-inheritance:
