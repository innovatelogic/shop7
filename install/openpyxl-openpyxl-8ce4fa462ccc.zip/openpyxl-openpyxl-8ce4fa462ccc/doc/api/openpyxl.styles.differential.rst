openpyxl.styles.differential module
===================================

.. automodule:: openpyxl.styles.differential
    :members:
    :undoc-members:
    :show-inheritance:
